
/**
 * Module dependencies.
 */

var express = require('express');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var expressValidator = require('express-validator');
const helmet = require('helmet');

var session = require('express-session');
var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
var MySQLStore = require('express-mysql-session')(session);
var bcrypt = require('bcryptjs');
var flash = require('connect-flash');

var app = express();
var urlendcodedParser = bodyParser.urlencoded({extended:true});
var fs = require('fs');
var httpOptions ={
		key: fs.readFileSync("keys/privatekey.pem"),
		 
		cert: fs.readFileSync("keys/certificate.pem")
 
};
var serv = require('https').Server(httpOptions, app);  //making a server
var path = require('path');
var routes = require('./routes');
var user = require('./routes/user');
var register = require('./routes/register');
var signIn = require('./routes/signIn');
var joinGame = require('./routes/joinGame');

//var dashboard = require('./routes/index');

const rateLimit = require("express-rate-limit");

 
const signInLimit = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour window
  max: 5, // start blocking after 5 requests
  message:
    "Too many attempts to join from this IP, please try again after an hour"
});




// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.bodyParser());
app.use(expressValidator());
app.use(express.methodOverride());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(helmet.contentSecurityPolicy({
	  directives: {
	    defaultSrc: ["'self'"],
	    styleSrc: ["'self'", 'https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css']
	  }
	}));

var options = {
		host: 'studentdb.cyyzuacupgts.us-east-1.rds.amazonaws.com',//127.0.0.1',
		user: 'studentdb',//'root',
		password : 'password',//'Z4j6eWRZ$p8n', 
		database:'studentdb'	    
	};
var sessionStore = new MySQLStore(options);
app.set('trust proxy', 1); // trust first proxy
app.use(session({
	secret: 'uytdfdjhdt',
	resave: false,
	name: 'wouroibamnbv',
    store: sessionStore,
	saveUninitialized: false,
	cookie: {httpOnly: true,secure:true,maxAge: 60000*60*24}
}));
app.use(passport.initialize());
app.use(passport.session());
app.use(flash());

app.use(app.router);
app.use(bodyParser.json());

var user_id;
const db = require('./databaseConnector.js'); 


passport.use(new LocalStrategy(
		  function(username, password, done) {
			  console.log(username);
			  console.log(password);
			  var db = require('./databaseConnector.js');
				db.query('SELECT * FROM user WHERE username=?',[username],function(error, results, fields){
					if(error){return done(error);}
					if(results.length === 0){
						return done(null, false);
					}
					else{
						console.log("results"+results[0]);
						var hash = results[0].password.toString();
						console.log("store pass"+results[0].id);
						bcrypt.compare(password, hash, function(err, res){
							if(res === true){
								return done(null, {user_id: results[0].id});
							}
							else{
								console.log("DIDNT MATCH");
								return done(null, false);
							}
						});
					}
					

				}); 
		  
		  }));








// development only
if ('development' === app.get('env')) {
  app.use(express.errorHandler());
}
/*app.get('/',function(req, res){
	res.sendfile(__dirname+'/views/index.html');
});*/


app.get('/', routes.index);
app.get('/users', user.list);
app.post('/register', urlendcodedParser, register.register);
app.post('/signIn',signInLimit,passport.authenticate('local',{successRedirect: '/dashboard', failureRedirect:'/', failureFlash: 'Invalid username or password.'}));//, urlendcodedParser, signIn.signIn);

app.get('/createAccount',register.createAccount);
app.get('/dashboard',authenticationMiddleware(),routes.dashboard);
app.get('/myHistory',authenticationMiddleware(),routes.myHistory);
app.get('/newGame',authenticationMiddleware(),routes.newGame);
app.get('/existingGame',authenticationMiddleware(),routes.existingGame);
app.get('/logout',routes.logout);
app.get('/error',routes.error);
app.get('/ludoRules',authenticationMiddleware(),routes.ludoRules);
app.post('/joinGame',authenticationMiddleware(),joinGame.join);
app.get('/joinGame',joinGame.handle);


/*
serv.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});*/

serv.listen(3000);
var SOCKET_LIST = {}; //to contain player list
var PlAYER_LIST = {};

var counter=0;

function authenticationMiddleware () {  //to check if the link is allowed to the user
	return (req, res, next) => {
		console.log("req.session.passport.user"+ JSON.stringify(req.session.passport));

	    if (req.isAuthenticated()) {return next();}
	    res.redirect('/');
	};
}

var player_list=[];
var io = require('socket.io')(serv,{});  //loads file and initializes it and returns io object
io.sockets.on('connection', function(socket){  //calls this function when client connects to the server
		//socket.id = Math.random();
	/*if(player_list.length!=0){
		
	}*/
		
		socket.id= counter;
		counter++;
		//socket.player=
		socket.color="red";
		console.log('client connected-----------------'+socket.id);
		socket.number = "" + Math.floor(10 * Math.random());
		socket.score_red=0;
		socket.score_yellow=0;
		
		SOCKET_LIST[socket.id] = socket;
		//console.log(SOCKET_LIST);
	
		socket.on('change',function(data){
			
			
			console.log("ON CHANGE"+data.x);
			console.log("ON CHANGE"+data.y);
			console.log("ON CHANGE"+data.playerTurn);
			console.log("ON CHANGE"+data.color);
			console.log("ON CHANGE"+data.id);
			console.log("ON CHANGE"+data.gameId);
			console.log("test"+data.score);

			db.query('UPDATE studentdb.gameState SET x'+data.id+'_'+data.color+'=?, y'+data.id+'_'+data.color+'=?, playerTurn=?, c'+data.id+'_'+data.color+
					'_pos=?, c'+data.id+'_'+data.color+'_zone=?, c'+data.id+'_'+data.color+'_bar1=?, c'+data.id+'_'+data.color+'_bar2=?, c'+
					data.id+'_'+data.color+'_bar3=?, c'+data.id+'_'+data.color+'_init=?, c'+data.id+'_'+data.color+'_firstMove=?, c'+data.id+
					'_'+data.color+'_lastMove=?, c'+data.id+'_'+data.color+'_home=?,score_'+data.color+'=?  WHERE gameId=?',[data.x,data.y,
						data.playerTurn,data.list.position,data.list.zone,data.list.bar1,data.list.bar2, data.list.bar3,
						data.list.initial,data.list.firstMove, data.list.lastMove,data.list.reachedHome,
						data.score,data.gameId],function(error,results,fields){
			

				if(error) throw error;
				else{
					console.log("STATE UPDATED!");
					db.query('UPDATE gameState SET logMoves = CONCAT_WS("<br>",logMoves, ?) WHERE gameId=?',[data.moveLog,data.gameId],function(error,result,field){
						if(error) throw error;
						else{
							console.log("Moves logged!");
						}
					});
				}
			});
			var pack = [];
			console.log('CHANGE');
			for(var i in SOCKET_LIST){
		        var socket = SOCKET_LIST[i];
				console.log("IN FOR LOOP"+socket.id);
				socket.x=data.x;
				socket.y=data.y;
				socket.id=data.id;
				socket.playerTurn=data.playerTurn;
				socket.color=data.color;
				if(socket.color=="red")
				socket.score_red = data.score;
				else
				socket.score_yellow = data.score;

				pack.push({
					x:socket.x,
					y:socket.y,
					id:socket.id,
					score_red:socket.score_red,
					score_yellow:socket.score_yellow,
					playerTurn:socket.playerTurn,
					color:socket.color
				});
		    }
			for(var i in SOCKET_LIST){
		        var socket = SOCKET_LIST[i];
		        socket.emit('newPositions',pack);
		        console.log("PUSHED!!");

			}
		});		
		socket.on('disconnect',function(){
			console.log('client disconnected'+socket.id);
			delete SOCKET_LIST[socket.id];
		});
		
	
});

 /*setInterval(function(){
    var pack = [];
    for(var i in SOCKET_LIST){
        var socket = SOCKET_LIST[i];
        socket.xR1=gameVar.x1_red;
        socket.yR1=gameVar.y1_red;
        pack.push({
            x:socket.xR1,
            y:socket.yR1,
            number:socket.number
        });    
    }
    for(var i in SOCKET_LIST){
        var socket = SOCKET_LIST[i];
        socket.emit('newPositions',pack);
    }
   
   
   
   
},1000/25 );*/
	

