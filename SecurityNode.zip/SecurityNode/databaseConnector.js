/**
 * 
 */
var mysql = require('mysql');
var connection = mysql.createConnection({
	host: 'studentdb.cyyzuacupgts.us-east-1.rds.amazonaws.com',//127.0.0.1',
	user: 'studentdb',//'root',
	password : 'password',//'Z4j6eWRZ$p8n', 
	insecureAuth : true,
	database:'studentdb'
	
});


connection.connect(function(error){
	if(!!error){
		console.log('ERROR '+error);
	}
	else{		
		console.log('SQL CONNECTED');
		connection.query("SELECT * from user",function(error, results, fields){
			console.log(results);
		});
	}
});
module.exports= connection;

/*var gameDb= CREATE TABLE `game` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `creator` int(11) DEFAULT NULL,
  `creatorColor` varchar(45) CHARACTER SET latin1 DEFAULT NULL,
  `player2` int(11) DEFAULT NULL,
  `player2Color` varchar(45) CHARACTER SET latin1 DEFAULT NULL,
  `playerNeeded` tinyint(4) DEFAULT '1',
  `gameFinished` tinyint(4) DEFAULT '0',
  `winner` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `creator_idx` (`creator`),
  CONSTRAINT `creator` FOREIGN KEY (`creator`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=216 DEFAULT CHARSET=utf8*/
		  
/*var userDb= CREATE TABLE `user` (
		  `id` int(11) NOT NULL AUTO_INCREMENT,
		  `username` varchar(45) CHARACTER SET latin1 DEFAULT NULL,
		  `password` varchar(255) DEFAULT NULL,
		  PRIMARY KEY (`id`),
		  UNIQUE KEY `username_UNIQUE` (`username`)
		) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8*/
  
/*var gameStateDb = CREATE TABLE `gameState` (
		  `id` int(11) NOT NULL AUTO_INCREMENT,
		  `x1_red` int(45) DEFAULT '100',
		  `y1_red` int(45) DEFAULT '350',
		  `x2_red` int(45) DEFAULT '132',
		  `y2_red` int(45) DEFAULT '382',
		  `x3_red` int(45) DEFAULT '68',
		  `y3_red` int(45) DEFAULT '382',
		  `x4_red` int(45) DEFAULT '100',
		  `y4_red` int(45) DEFAULT '414',
		  `x1_yellow` int(45) DEFAULT '382',
		  `y1_yellow` int(45) DEFAULT '67',
		  `x2_yellow` int(45) DEFAULT '414',
		  `y2_yellow` int(45) DEFAULT '99',
		  `x3_yellow` int(45) DEFAULT '350',
		  `y3_yellow` int(45) DEFAULT '99',
		  `x4_yellow` int(45) DEFAULT '382',
		  `y4_yellow` int(45) DEFAULT '131',
		  `score_red` int(45) DEFAULT '0',
		  `score_yellow` int(45) DEFAULT '0',
		  `c1_red_pos` int(45) DEFAULT '0',
		  `c1_red_zone` int(45) DEFAULT '0',
		  `c1_red_bar1` tinyint(4) DEFAULT '0',
		  `c1_red_bar2` tinyint(4) DEFAULT '0',
		  `c1_red_bar3` tinyint(4) DEFAULT '0',
		  `c1_red_init` tinyint(4) DEFAULT '1',
		  `c1_red_firstMove` tinyint(4) DEFAULT '1',
		  `c1_red_lastMove` tinyint(4) DEFAULT '0',
		  `c1_red_home` tinyint(4) DEFAULT '0',
		  `c2_red_pos` int(45) DEFAULT '0',
		  `c2_red_zone` int(45) DEFAULT '0',
		  `c2_red_bar1` tinyint(4) DEFAULT '0',
		  `c2_red_bar2` tinyint(4) DEFAULT '0',
		  `c2_red_bar3` tinyint(4) DEFAULT '0',
		  `c2_red_init` tinyint(4) DEFAULT '1',
		  `c2_red_firstMove` tinyint(4) DEFAULT '1',
		  `c2_red_lastMove` tinyint(4) DEFAULT '0',
		  `c2_red_home` tinyint(4) DEFAULT '0',
		  `c3_red_pos` int(45) DEFAULT '0',
		  `c3_red_zone` int(45) DEFAULT '0',
		  `c3_red_bar1` tinyint(4) DEFAULT '0',
		  `c3_red_bar2` tinyint(4) DEFAULT '0',
		  `c3_red_bar3` tinyint(4) DEFAULT '0',
		  `c3_red_init` tinyint(4) DEFAULT '1',
		  `c3_red_firstMove` tinyint(4) DEFAULT '1',
		  `c3_red_lastMove` tinyint(4) DEFAULT '0',
		  `c3_red_home` tinyint(4) DEFAULT '0',
		  `c4_red_pos` int(45) DEFAULT '0',
		  `c4_red_zone` int(45) DEFAULT '0',
		  `c4_red_bar1` tinyint(4) DEFAULT '0',
		  `c4_red_bar2` tinyint(4) DEFAULT '0',
		  `c4_red_bar3` tinyint(4) DEFAULT '0',
		  `c4_red_init` tinyint(4) DEFAULT '1',
		  `c4_red_firstMove` tinyint(4) DEFAULT '1',
		  `c4_red_lastMove` tinyint(4) DEFAULT '0',
		  `c4_red_home` tinyint(4) DEFAULT '0',
		  `c1_yellow_pos` int(45) DEFAULT '0',
		  `c1_yellow_zone` int(45) DEFAULT '0',
		  `c1_yellow_bar1` tinyint(4) DEFAULT '0',
		  `c1_yellow_bar2` tinyint(4) DEFAULT '0',
		  `c1_yellow_bar3` tinyint(4) DEFAULT '0',
		  `c1_yellow_init` tinyint(4) DEFAULT '1',
		  `c1_yellow_firstMove` tinyint(4) DEFAULT '1',
		  `c1_yellow_lastMove` tinyint(4) DEFAULT '0',
		  `c1_yellow_home` tinyint(4) DEFAULT '0',
		  `c2_yellow_pos` int(45) DEFAULT '0',
		  `c2_yellow_zone` int(45) DEFAULT '0',
		  `c2_yellow_bar1` tinyint(4) DEFAULT '0',
		  `c2_yellow_bar2` tinyint(4) DEFAULT '0',
		  `c2_yellow_bar3` tinyint(4) DEFAULT '0',
		  `c2_yellow_init` tinyint(4) DEFAULT '1',
		  `c2_yellow_firstMove` tinyint(4) DEFAULT '1',
		  `c2_yellow_lastMove` tinyint(4) DEFAULT '0',
		  `c2_yellow_home` tinyint(4) DEFAULT '0',
		  `c3_yellow_pos` int(45) DEFAULT '0',
		  `c3_yellow_zone` int(45) DEFAULT '0',
		  `c3_yellow_bar1` tinyint(4) DEFAULT '0',
		  `c3_yellow_bar2` tinyint(4) DEFAULT '0',
		  `c3_yellow_bar3` tinyint(4) DEFAULT '0',
		  `c3_yellow_init` tinyint(4) DEFAULT '1',
		  `c3_yellow_firstMove` tinyint(4) DEFAULT '1',
		  `c3_yellow_lastMove` tinyint(4) DEFAULT '0',
		  `c3_yellow_home` tinyint(4) DEFAULT '0',
		  `c4_yellow_pos` int(45) DEFAULT '0',
		  `c4_yellow_zone` int(45) DEFAULT '0',
		  `c4_yellow_bar1` tinyint(4) DEFAULT '0',
		  `c4_yellow_bar2` tinyint(4) DEFAULT '0',
		  `c4_yellow_bar3` tinyint(4) DEFAULT '0',
		  `c4_yellow_init` tinyint(4) DEFAULT '1',
		  `c4_yellow_firstMove` tinyint(4) DEFAULT '1',
		  `c4_yellow_lastMove` tinyint(4) DEFAULT '0',
		  `c4_yellow_home` tinyint(4) DEFAULT '0',
		  `logMoves` text,
		  `playerTurn` int(11) DEFAULT '0',
		  `gameId` int(11) NOT NULL,
		  `winner` int(11) DEFAULT NULL,
		  `gameStatecol` varchar(45) DEFAULT NULL,
		  PRIMARY KEY (`id`),
		  KEY `gameId_idx` (`gameId`),
		  KEY `winner_idx` (`winner`),
		  CONSTRAINT `gameId` FOREIGN KEY (`gameId`) REFERENCES `game` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
		  CONSTRAINT `winner` FOREIGN KEY (`winner`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
		) ENGINE=InnoDB AUTO_INCREMENT=184 DEFAULT CHARSET=latin1*/