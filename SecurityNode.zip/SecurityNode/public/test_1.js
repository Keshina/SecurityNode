/**
 * 
 */
function classFile(thecanvas, bcanvas){
	this.redcone = thecanvas; //canvas
	this.bg= bcanvas; //bcanvas
	this.placePiece = placePiece; //placeimg
	this.clear=clear;
	this.placeBoard = placeBoard; // bimage
}

function placePiece(image, x, y, width, height){ //placeimg
	var canvas = document.getElementById(this.redcone);
	var context = canvas.getContext('2d');
	context.drawImage(image,x,y,width,height);
	
}

function clear(){
	var cnvs = document.getElementById(this.redcone);
	var cntxt= cnvs.getContext('2d');
	cntxt.clearRect(0,0,cnvs.width, cnvs.height);
}

function placeBoard(ludoImage){  //bimage
	var cnvs = document.getElementById(this.bg);
	var cntxt = cnvs.getContext('2d');
	cntxt.drawImage(ludoImage,0,0,cnvs.width, cnvs.height);
}

var  redC1 = new Image();
var  redC2 = new Image();
var  redC3 = new Image();
var  redC4 = new Image();
var  yellowC1 = new Image();
var  yellowC2 = new Image();
var  yellowC3 = new Image();
var  yellowC4 = new Image();


var ludo = new Image();


var test = new classFile("piece","board");
function setup(){
	//add socket stuff depending on which user joined, set up that way
	redC1.src = 'rC1.png';
	redC1.id ="redC1";
	redC2.src = 'rC2.png';
	redC3.src = 'rC3.png';
	redC4.src = 'rC4.png';
	ludo.src = 'Ludo_board.png';
	yellowC1.src = 'yC.png';
	yellowC1.id = 'yellowC1';
	yellowC2.src = 'yC1.png';
	yellowC3.src = 'yC2.png';
	yellowC4.src = 'yC3.png';
	document.getElementById("diceTurn").innerHTML = "Player 1 - roll the dice:";
	
	
	disableRed();
	disableYellow();
	
}
function yellowInitialPlacement(){
	//initial yellow placement
	x1_yellow = 382;
	y1_yellow = 67;
	x2_yellow = 382+box;
	y2_yellow = 67+box;
	x3_yellow = 382-box;
	y3_yellow = 67+box;
	x4_yellow = 382;
	y4_yellow = 67+box+box;
	test.placePiece(yellowC1,x1_yellow,y1_yellow,26,26); 
	test.placePiece(yellowC2,x2_yellow,y2_yellow,26,26);
	test.placePiece(yellowC3,x3_yellow,y3_yellow,26,26);
	test.placePiece(yellowC4,x4_yellow,y4_yellow,26,26);
	
}

function loadYellow(){
	//current yellow placement
	
	test.placePiece(yellowC1,x1_yellow,y1_yellow,26,26); 
	test.placePiece(yellowC2,x2_yellow,y2_yellow,26,26);
	test.placePiece(yellowC3,x3_yellow,y3_yellow,26,26);
	test.placePiece(yellowC4,x4_yellow,y4_yellow,26,26);
	
}
function redInitialPlacement(){
	//initial red placement
	x1_red = 100;
	y1_red = 350;
	x2_red = 100+box;
	y2_red = 382;
	x3_red = 100-box;
	y3_red = 382;
	x4_red = 100;
	y4_red = 350+box+box;
	test.placePiece(redC1,x1_red,y1_red,26,26); 
	test.placePiece(redC2,x2_red,y2_red,26,26);
	test.placePiece(redC3,x3_red,y3_red,26,26);
	test.placePiece(redC4,x4_red,y4_red,26,26);
	
}

function loadRed(){
	//current red placement
	
	test.placePiece(redC1,x1_red,y1_red,26,26); 
	test.placePiece(redC2,x2_red,y2_red,26,26);
	test.placePiece(redC3,x3_red,y3_red,26,26);
	test.placePiece(redC4,x4_red,y4_red,26,26);
	
}

var box=32;
var x1_red = 0;
var y1_red = 0;
var x2_red = 0;
var y2_red = 0;
var x3_red = 0;
var y3_red = 0;
var x4_red = 0;
var y4_red = 0;
var x1_yellow = 0;
var y1_yellow = 0;
var x2_yellow = 0;
var y2_yellow = 0;
var x3_yellow = 0;
var y3_yellow = 0;
var x4_yellow = 0;
var y4_yellow = 0;
var initializeGame = true;
var xToMove_Yellow = 0;
var yToMove_yellow = 0;
//player 1 == 0, player 2 == 1
var playerTurn = 0;
var list = [
    { position: 0, zone: 0, bar1: false, bar2: false, bar3: false, initial: true, firstMove: true, lastMove: false},
    { position: 0, zone: 0, bar1: false, bar2: false, bar3: false, initial: true, firstMove: true, lastMove: false},
    { position: 0, zone: 0, bar1: false, bar2: false, bar3: false, initial: true, firstMove: true, lastMove: false},
    { position: 0, zone: 0, bar1: false, bar2: false, bar3: false, initial: true, firstMove: true, lastMove: false}
];

var list_yellow = [
    { position: 0, zone: 0, bar1: false, bar2: false, bar3: false, initial: true, firstMove: true, lastMove: false},
    { position: 0, zone: 0, bar1: false, bar2: false, bar3: false, initial: true, firstMove: true, lastMove: false},
    { position: 0, zone: 0, bar1: false, bar2: false, bar3: false, initial: true, firstMove: true, lastMove: false},
    { position: 0, zone: 0, bar1: false, bar2: false, bar3: false, initial: true, firstMove: true, lastMove: false}
];
function startGame(){
	test.placeBoard(ludo);
	test.clear();
	redInitialPlacement();
	yellowInitialPlacement();

}
function loadGame(color,x,y){
	var id = "1";
	console.log("loadGame");
	//test.placeBoard(ludo);
	//test.clear();
	if(color=='red'){
		if(id=="1"){
			test.placePiece(redC1,x,y,26,26); 

		}
	}
	if(color=='yellow'){
		if(id=="1"){
			test.placePiece(yellowC1,x,y,26,26); 

		}
	}

	
	
}
function whenMove(){
	drawCones();
	drawConesYellow();
	if(coneMoveBy == 1 && random == 2 || coneMoveBy == 2 && random == 4 || coneMoveBy == 3 && random == 6){
		var dby2 = random/2;
		random = random - dby2;
		document.getElementById("status").innerHTML = "You still have " + random + " moves!";
	}
	
	else{
		random = 0;
		if(playerTurn == 0){
			document.getElementById("diceTurn").innerHTML = "Player 2 - roll the dice:";
			document.getElementById("status").innerHTML = "";
		}
		else if (playerTurn == 1){
			document.getElementById("diceTurn").innerHTML = "Player 1 - roll the dice:";
			document.getElementById("status").innerHTML = "";
		}
		if(playerTurn == 0){
			playerTurn = 1;
			
		}
		else if(playerTurn == 1){
			playerTurn = 0;
			
		}
	}
	disableRed();
	disableYellow();
	buttonSetup();
}
var coneMoveBy;
function moveCone1By1(data){
	moveRed(1,1,1);
	coneMoveBy = 1;
	whenMove();
	data.emit('change',{x:x1_red,y:y1_red,color:"red"});

	
}
function moveCone1By2(data){
	moveRed(1,1,2);
	coneMoveBy = 2;
	whenMove();
	data.emit('change',{x:x1_red,y:y1_red,color:"red"});

}
function moveCone1By3(data){
	moveRed(1,1,3);
	coneMoveBy = 3;
	whenMove();
	data.emit('change',{x:x1_red,y:y1_red,color:"red"});

}
function moveCone1By4(data){
	moveRed(1,1,4);
	coneMoveBy = 4;
	whenMove();
	data.emit('change',{x:x1_red,y:y1_red,color:"red"});

}
function moveCone1By5(data){
	moveRed(1,1,5);
	coneMoveBy = 5;
	whenMove();
	data.emit('change',{x:x1_red,y:y1_red,color:"red"});

}
function moveCone1By6(data){
	moveRed(1,1,6);
	coneMoveBy = 6;
	whenMove();
	data.emit('change',{x:x1_red,y:y1_red,color:"red"});

}
//##################################################################################################################################3
function moveCone2By1(){
	moveRed(2,1,1);
	coneMoveBy = 1;
	whenMove();
}
function moveCone2By2(){
	moveRed(2,1,2);
	coneMoveBy = 2;
	whenMove();
}
function moveCone2By3(){
	moveRed(2,1,3);
	coneMoveBy = 3;
	whenMove();
}
function moveCone2By4(){
	moveRed(2,1,4);
	coneMoveBy = 4;
	whenMove();
}
function moveCone2By5(){
	moveRed(2,1,5);
	coneMoveBy = 5;
	whenMove();
}
function moveCone2By6(){
	moveRed(2,1,6);
	coneMoveBy = 6;
	whenMove();
}
function moveCone3By1(){
	moveRed(3,1,1);
	coneMoveBy = 1;
	whenMove();
}
function moveCone3By2(){
	moveRed(3,1,2);
	coneMoveBy = 2;
	whenMove();
}
function moveCone3By3(){
	moveRed(3,1,3);
	coneMoveBy = 3;
	whenMove();
}
function moveCone3By4(){
	moveRed(3,1,4);
	coneMoveBy = 4;
	whenMove();
}
function moveCone3By5(){
	moveRed(3,1,5);
	coneMoveBy = 5;
	whenMove();
}
function moveCone3By6(){
	moveRed(3,1,6);
	coneMoveBy = 6;
	whenMove();
}
function moveCone4By1(){
	moveRed(4,1,1);
	coneMoveBy = 1;
	whenMove();
}
function moveCone4By2(){
	moveRed(4,1,2);
	coneMoveBy = 2;
	whenMove();
}
function moveCone4By3(){
	moveRed(4,1,3);
	coneMoveBy = 3;
	whenMove();
}
function moveCone4By4(){
	moveRed(4,1,4);
	coneMoveBy = 4;
	whenMove();
}
function moveCone4By5(){
	moveRed(4,1,5);
	coneMoveBy = 5;
	whenMove();
}
function moveCone4By6(){
	moveRed(4,1,6);
	coneMoveBy = 6;
	whenMove();
}

//############################################################################################################33

function moveConeY1By1(data){
	moveYellow(1,1,1);
	coneMoveBy = 1;
	whenMove();
	data.emit('change',{x:x1_yellow,y:y1_yellow,color:"yellow"});

}
function moveConeY1By2(data){
	moveYellow(1,1,2);
	coneMoveBy = 2;
	whenMove();
	data.emit('change',{x:x1_yellow,y:y1_yellow,color:"yellow"});

}
function moveConeY1By3(data){
	moveYellow(1,1,3);
	coneMoveBy = 3;
	whenMove();
	data.emit('change',{x:x1_yellow,y:y1_yellow,color:"yellow"});

}
function moveConeY1By4(data){
	moveYellow(1,1,4);
	coneMoveBy = 4;
	whenMove();
	data.emit('change',{x:x1_yellow,y:y1_yellow,color:"yellow"});

}
function moveConeY1By5(data){
	moveYellow(1,1,5);
	coneMoveBy = 5;
	whenMove();
	data.emit('change',{x:x1_yellow,y:y1_yellow,color:"yellow"});

}
function moveConeY1By6(data){
	moveYellow(1,1,6);
	coneMoveBy = 6;
	whenMove();
	data.emit('change',{x:x1_yellow,y:y1_yellow,color:"yellow"});

}

function moveConeY2By1(){
	moveYellow(2,1,1);
	coneMoveBy = 1;
	whenMove();
}
function moveConeY2By2(){
	moveYellow(2,1,2);
	coneMoveBy = 2;
	whenMove();
}
function moveConeY2By3(){
	moveYellow(2,1,3);
	coneMoveBy = 3;
	whenMove();
}
function moveConeY2By4(){
	moveYellow(2,1,4);
	coneMoveBy = 4;
	whenMove();
}
function moveConeY2By5(){
	moveYellow(2,1,5);
	coneMoveBy = 5;
	whenMove();
}
function moveConeY2By6(){
	moveYellow(2,1,6);
	coneMoveBy = 6;
	whenMove();
}
function moveConeY3By1(){
	moveYellow(3,1,1);
	coneMoveBy = 1;
	whenMove();
}
function moveConeY3By2(){
	moveYellow(3,1,2);
	coneMoveBy = 2;
	whenMove();
}
function moveConeY3By3(){
	moveYellow(3,1,3);
	coneMoveBy = 3;
	whenMove();
}
function moveConeY3By4(){
	moveYellow(3,1,4);
	coneMoveBy = 4;
	whenMove();
}
function moveConeY3By5(){
	moveYellow(3,1,5);
	coneMoveBy = 5;
	whenMove();
}
function moveConeY3By6(){
	moveYellow(3,1,6);
	coneMoveBy = 6;
	whenMove();
}
function moveConeY4By1(){
	moveYellow(4,1,1);
	coneMoveBy = 1;
	whenMove();
}
function moveConeY4By2(){
	moveYellow(4,1,2);
	coneMoveBy = 2;
	whenMove();
}
function moveConeY4By3(){
	moveYellow(4,1,3);
	coneMoveBy = 3;
	whenMove();
}
function moveConeY4By4(){
	moveYellow(4,1,4);
	coneMoveBy = 4;
	whenMove();
}
function moveConeY4By5(){
	moveYellow(4,1,5);
	coneMoveBy = 5;
	whenMove();
}
function moveConeY4By6(){
	moveYellow(4,1,6);
	coneMoveBy = 6;
	whenMove();
}

//x1 and y1 here just refer to any cone that needs to be moved
///assuming id = "cone 1" is passed
function drawConesYellow(){
	console.log("DRAW YELLOW");
	test.placePiece(yellowC1,x1_yellow,y1_yellow,26,26); 
	test.placePiece(yellowC2,x2_yellow,y2_yellow,26,26);
	test.placePiece(yellowC3,x3_yellow,y3_yellow,26,26);
	test.placePiece(yellowC4,x4_yellow,y4_yellow,26,26);
	checkCollision();
	
}
function drawCones(){
	console.log("DRAW Red");

	test.placePiece(redC1,x1_red,y1_red,26,26); 
	test.placePiece(redC2,x2_red,y2_red,26,26);
	test.placePiece(redC3,x3_red,y3_red,26,26);
	test.placePiece(redC4,x4_red,y4_red,26,26);
	
}


function moveYellow(id,dice,placeMove){
	var i;
	for (i = 1; i <= placeMove; i++) { 
	
	test.placeBoard(ludo);
	test.clear();
	
	if(list_yellow[0].firstMove==true && id == 1){
		list_yellow[0].zone = 1;
		list_yellow[0].bar3 = true; 
		x1_yellow = 370-box-box-box;
		y1_yellow = 52;
		list_yellow[0].firstMove = false;
		return;
	}
	else if(list_yellow[1].firstMove==true && id == 2){
		list_yellow[1].zone = 1;
		list_yellow[1].bar3 = true; 
		x2_yellow = 370-box-box-box;
		y2_yellow = 52;
		list_yellow[1].firstMove = false;
		return;
	}
	else if(list_yellow[2].firstMove==true && id == 3){
		list_yellow[2].zone = 1;
		list_yellow[2].bar3 = true; 
		x3_yellow = 370-box-box-box;
		y3_yellow = 52;
		list_yellow[2].firstMove = false;
		return;
	}
	if(list_yellow[3].firstMove==true && id == 4){
		list_yellow[3].zone = 1;
		list_yellow[3].bar3 = true; 
		x4_yellow = 370-box-box-box;
		y4_yellow = 52;
		list_yellow[3].firstMove = false;
		return;
	}
	
	
	if(id==1){
		
		xToMove = x1_yellow;
		yToMove = y1_yellow;
	}
	
	else if(id==2){
		xToMove = x2_yellow;
		yToMove = y2_yellow;
	}
	else if(id==3){
		xToMove = x3_yellow;
		yToMove = y3_yellow;
	}
	else if(id==4){
		xToMove = x4_yellow;
		yToMove = y4_yellow;
	}
	moveConeYellow(id);

	
	}	
}


function moveRed(id,dice,placeMove){
	var i;
	for (i = 1; i <= placeMove; i++) { 
	
	test.placeBoard(ludo);
	test.clear();
	
	if(list[0].firstMove==true && id == 1){
		list[0].zone = 1;
		list[0].bar3 = true; 
		x1_red = 100+box+box+box+14;
		y1_red = 350+box+box+15;
		list[0].firstMove = false;
		return;
	}
	else if(list[1].firstMove==true && id == 2){
		list[1].zone = 1;
		list[1].bar3 = true; 
		x2_red = 100+box+box+box+14;
		y2_red = 350+box+box+15;
		list[1].firstMove = false;
		return;
	}
	else if(list[2].firstMove==true && id == 3){
		list[2].zone = 1;
		list[2].bar3 = true; 
		x3_red = 100+box+box+box+14;
		y3_red = 350+box+box+15;
		list[2].firstMove = false;
		return;
	}
	if(list[3].firstMove==true && id == 4){
		list[3].zone = 1;
		list[3].bar3 = true; 
		x4_red = 100+box+box+box+14;
		y4_red = 350+box+box+15;
		list[3].firstMove = false;
		return;
	}
	
	
	if(id==1){
		
		xToMove = x1_red;
		yToMove = y1_red;
	}
	
	else if(id==2){
		xToMove = x2_red;
		yToMove = y2_red;
	}
	else if(id==3){
		xToMove = x3_red;
		yToMove = y3_red;
	}
	else if(id==4){
		xToMove = x4_red;
		yToMove = y4_red;
	}
	moveCone(id);

	
	}	
}

//################################################################################################
//big function for yellow
function moveConeYellow(id){
	list_yellow[id - 1].position++;
	
	if(list_yellow[id - 1].zone == 1 && list_yellow[id - 1].position<5 && list_yellow[id - 1].bar3 == true && list_yellow[id - 1].initial == true){//user home, bar 3
		yToMove = yToMove+box;
		if(id == 1){
			x1_yellow = xToMove;
			y1_yellow = yToMove;
		}
		else if(id == 2){
			x2_yellow = xToMove;
			y2_yellow = yToMove;
		}
		else if(id == 3){
			x3_yellow = xToMove;
			y3_yellow = yToMove;
		}
		else if(id == 4){
			x4_yellow = xToMove;
			y4_yellow = yToMove;
		}

	}
	
	else if(list_yellow[id - 1].zone == 1 && list_yellow[id - 1].position==5&& list_yellow[id - 1].initial == true){
		yToMove = yToMove+box;
		xToMove = xToMove+box;
		if(id == 1){
			x1_yellow = xToMove;
			y1_yellow = yToMove;
		}
		else if(id == 2){
			x2_yellow = xToMove;
			y2_yellow = yToMove;
		}
		else if(id == 3){
			x3_yellow = xToMove;
			y3_yellow = yToMove;
		}
		else if(id == 4){
			x4_yellow = xToMove;
			y4_yellow = yToMove;
		}
		list_yellow[id - 1].zone++;
		list_yellow[id - 1].position = 0;
		list_yellow[id - 1].bar1 = true;
		list_yellow[id - 1].initial = false;
	}
	
	//zone 2, bar 1
	else if(list_yellow[id - 1].bar1 == true && list_yellow[id - 1].zone == 2 && list_yellow[id - 1].position <= 5){
		xToMove = xToMove+box;
		if(id == 1){
			x1_yellow = xToMove;
			y1_yellow = yToMove;
		}
		else if(id == 2){
			x2_yellow = xToMove;
			y2_yellow = yToMove;
		}
		else if(id == 3){
			x3_yellow = xToMove;
			y3_yellow = yToMove;
		}
		else if(id == 4){
			x4_yellow = xToMove;
			y4_yellow = yToMove;
		}
		if(list_yellow[id - 1].position == 5){
			list_yellow[id - 1].position = 1;
			list_yellow[id - 1].bar1 = false;
			list_yellow[id - 1].bar2 = true;
			return;
		}
	}
	
	//zone 2, bar 2
	if(list_yellow[id - 1].bar1 == false && list_yellow[id - 1].bar2 == true && list_yellow[id - 1].position <= 3 && list_yellow[id - 1].zone == 2){
		yToMove = yToMove+box;
		if(id == 1){
			x1_yellow = xToMove;
			y1_yellow = yToMove;
		}
		else if(id == 2){
			x2_yellow = xToMove;
			y2_yellow = yToMove;
		}
		else if(id == 3){
			x3_yellow = xToMove;
			y3_yellow = yToMove;
		}
		else if(id == 4){
			x4_yellow = xToMove;
			y4_yellow = yToMove;
		}
		if(list_yellow[id - 1].position == 3){
			list_yellow[id - 1].position = 1;
			list_yellow[id - 1].bar1 = false;
			list_yellow[id - 1].bar2 = false;
			list_yellow[id - 1].bar3 = true;
			return;
		}
	}
	
	//zone 2, bar 3
	if(list_yellow[id - 1].bar1 == false && list_yellow[id - 1].bar2 == false && list_yellow[id - 1].bar3 ==true && list_yellow[id - 1].position <= 6 && list_yellow[id - 1].zone == 2){
		xToMove = xToMove-box;
		if(id == 1){
			x1_yellow = xToMove;
			y1_yellow = yToMove;
		}
		else if(id == 2){
			x2_yellow = xToMove;
			y2_yellow = yToMove;
		}
		else if(id == 3){
			x3_yellow = xToMove;
			y3_yellow = yToMove;
		}
		else if(id == 4){
			x4_yellow = xToMove;
			y4_yellow = yToMove;
		}
		if(list_yellow[id - 1].position == 6){
			list_yellow[id - 1].zone++;
			return;
		}
	}
	
	//zone 3, special case
	else if(list_yellow[id - 1].zone == 3 && list_yellow[id - 1].bar3 == true && list_yellow[id - 1].position == 7){
		list_yellow[id - 1].bar3 = false;
			yToMove = yToMove+box;
			xToMove = xToMove-box;
			if(id == 1){
				x1_yellow = xToMove;
				y1_yellow = yToMove;
			}
			else if(id == 2){
				x2_yellow = xToMove;
				y2_yellow = yToMove;
			}
			else if(id == 3){
				x3_yellow = xToMove;
				y3_yellow = yToMove;
			}
			else if(id == 4){
				x4_yellow = xToMove;
				y4_yellow = yToMove;
			}
			list_yellow[id - 1].position = 0;
			list_yellow[id - 1].bar1 = true;
			return;
		
	}
		
	///CODE FOR ZONE 3,bar 1
	if(list_yellow[id - 1].bar1 == true && list_yellow[id - 1].zone == 3 && list_yellow[id - 1].position <= 5){
		yToMove = yToMove+box;
		if(id == 1){
			x1_yellow = xToMove;
			y1_yellow = yToMove;
		}
		else if(id == 2){
			x2_yellow = xToMove;
			y2_yellow = yToMove;
		}
		else if(id == 3){
			x3_yellow = xToMove;
			y3_yellow = yToMove;
		}
		else if(id == 4){
			x4_yellow = xToMove;
			y4_yellow = yToMove;
		}
		if(list_yellow[id - 1].position == 5){
			list_yellow[id - 1].position = 1;
			list_yellow[id - 1].bar1 = false;
			list_yellow[id - 1].bar2 = true;
			return;
		}
	}
	//zone 3, bar 2
	if(list_yellow[id - 1].bar1 == false && list_yellow[id - 1].bar2 == true && list_yellow[id - 1].position <= 3 && list_yellow[id - 1].zone == 3){
		xToMove = xToMove-box;
		if(id == 1){
			x1_yellow = xToMove;
			y1_yellow = yToMove;
		}
		else if(id == 2){
			x2_yellow = xToMove;
			y2_yellow = yToMove;
		}
		else if(id == 3){
			x3_yellow = xToMove;
			y3_yellow = yToMove;
		}
		else if(id == 4){
			x4_yellow = xToMove;
			y4_yellow = yToMove;
		}
		if(list_yellow[id - 1].position == 3){
			list_yellow[id - 1].position = 1;
			list_yellow[id - 1].bar1 = false;
			list_yellow[id - 1].bar2 = false;
			list_yellow[id - 1].bar3 = true;
			return;
		}
	}
	
	//zone 3, bar 3
	if(list_yellow[id - 1].bar1 == false && list_yellow[id - 1].bar2 == false && list_yellow[id - 1].bar3 ==true && list_yellow[id - 1].position <= 6 && list_yellow[id - 1].zone == 3){
		yToMove = yToMove-box;
		if(id == 1){
			x1_yellow = xToMove;
			y1_yellow = yToMove;
		}
		else if(id == 2){
			x2_yellow = xToMove;
			y2_yellow = yToMove;
		}
		else if(id == 3){
			x3_yellow = xToMove;
			y3_yellow = yToMove;
		}
		else if(id == 4){
			x4_yellow = xToMove;
			y4_yellow = yToMove;
		}
		if(list_yellow[id - 1].position == 6){
			list_yellow[id - 1].zone++;
			return;
		}
	}
	
	//zone 4, special case
	else if(list_yellow[id - 1].zone == 4 && list_yellow[id - 1].bar3 == true && list_yellow[id - 1].position == 7){
		list_yellow[id - 1].bar3 = false;
			yToMove = yToMove-box;
			xToMove = xToMove-box;
			if(id == 1){
				x1_yellow = xToMove;
				y1_yellow = yToMove;
			}
			else if(id == 2){
				x2_yellow = xToMove;
				y2_yellow = yToMove;
			}
			else if(id == 3){
				x3_yellow = xToMove;
				y3_yellow = yToMove;
			}
			else if(id == 4){
				x4_yellow = xToMove;
				y4_yellow = yToMove;
			}
			list_yellow[id - 1].position = 0;
			list_yellow[id - 1].bar1 = true;
			return;
		
	}
		
	///CODE FOR ZONE 4,bar 1
	if(list_yellow[id - 1].bar1 == true && list_yellow[id - 1].zone == 4 && list_yellow[id - 1].position <= 5){
		xToMove = xToMove-box;
		if(id == 1){
			x1_yellow = xToMove;
			y1_yellow = yToMove;
		}
		else if(id == 2){
			x2_yellow = xToMove;
			y2_yellow = yToMove;
		}
		else if(id == 3){
			x3_yellow = xToMove;
			y3_yellow = yToMove;
		}
		else if(id == 4){
			x4_yellow = xToMove;
			y4_yellow = yToMove;
		}
		if(list_yellow[id - 1].position == 5){
			list_yellow[id - 1].position = 1;
			list_yellow[id - 1].bar1 = false;
			list_yellow[id - 1].bar2 = true;
			return;
		}
	}
	//zone 4, bar 2
	if(list_yellow[id - 1].bar1 == false && list_yellow[id - 1].bar2 == true && list_yellow[id - 1].position <= 3 && list_yellow[id - 1].zone == 4){
		yToMove = yToMove-box;
		if(id == 1){
			x1_yellow = xToMove;
			y1_yellow = yToMove;
		}
		else if(id == 2){
			x2_yellow = xToMove;
			y2_yellow = yToMove;
		}
		else if(id == 3){
			x3_yellow = xToMove;
			y3_yellow = yToMove;
		}
		else if(id == 4){
			x4_yellow = xToMove;
			y4_yellow = yToMove;
		}
		if(list_yellow[id - 1].position == 3){
			list_yellow[id - 1].position = 1;
			list_yellow[id - 1].bar1 = false;
			list_yellow[id - 1].bar2 = false;
			list_yellow[id - 1].bar3 = true;
			return;
		}
	}
	//zone 4, bar 3
	if(list_yellow[id - 1].bar1 == false && list_yellow[id - 1].bar2 == false && list_yellow[id - 1].bar3 ==true && list_yellow[id - 1].position <= 6 && list_yellow[id - 1].zone == 4){
		xToMove = xToMove+box;
		if(id == 1){
			x1_yellow = xToMove;
			y1_yellow = yToMove;
		}
		else if(id == 2){
			x2_yellow = xToMove;
			y2_yellow = yToMove;
		}
		else if(id == 3){
			x3_yellow = xToMove;
			y3_yellow = yToMove;
		}
		else if(id == 4){
			x4_yellow = xToMove;
			y4_yellow = yToMove;
		}
		if(list_yellow[id - 1].position == 6){
			list_yellow[id - 1].zone = 1;
			return;
		}
	}
	
	//zone 1, special case
	else if(list_yellow[id - 1].zone == 1 && list_yellow[id - 1].bar3 == true && list_yellow[id - 1].position == 7){
			yToMove = yToMove-box;
			xToMove = xToMove+box;
			if(id == 1){
				x1_yellow = xToMove;
				y1_yellow = yToMove;
			}
			else if(id == 2){
				x2_yellow = xToMove;
				y2_yellow = yToMove;
			}
			else if(id == 3){
				x3_yellow = xToMove;
				y3_yellow = yToMove;
			}
			else if(id == 4){
				x4_yellow = xToMove;
				y4_yellow = yToMove;
			}
			list_yellow[id - 1].zone = 1;
			list_yellow[id - 1].position = 0;
			list_yellow[id - 1].bar1 = true;
			list_yellow[id - 1].bar3 = false;
			return;
		
	}
	///CODE FOR ZONE 1,bar 1
	if(list_yellow[id - 1].bar1 == true && list_yellow[id - 1].zone == 1 && list_yellow[id - 1].position <= 5){
		yToMove = yToMove-box;
		if(id == 1){
			x1_yellow = xToMove;
			y1_yellow = yToMove;
		}
		else if(id == 2){
			x2_yellow = xToMove;
			y2_yellow = yToMove;
		}
		else if(id == 3){
			x3_yellow = xToMove;
			y3_yellow = yToMove;
		}
		else if(id == 4){
			x4_yellow = xToMove;
			y4_yellow = yToMove;
		}
		if(list_yellow[id - 1].position == 5){
			list_yellow[id - 1].position = 1;
			list_yellow[id - 1].bar1 = false;
			list_yellow[id - 1].bar2 = true;
			return;
		}
	}
	//zone 1, bar 2
	if(list_yellow[id - 1].bar1 == false && list_yellow[id - 1].bar2 == true && list_yellow[id - 1].position <= 2 && list_yellow[id - 1].zone == 1){
		xToMove = xToMove+box;
		if(id == 1){
			x1_yellow = xToMove;
			y1_yellow = yToMove;
		}
		else if(id == 2){
			x2_yellow = xToMove;
			y2_yellow = yToMove;
		}
		else if(id == 3){
			x3_yellow = xToMove;
			y3_yellow = yToMove;
		}
		else if(id == 4){
			x4_yellow = xToMove;
			y4_yellow = yToMove;
		}
		if(list_yellow[id - 1].position == 2){
			list_yellow[id - 1].position = 1;
			list_yellow[id - 1].bar1 = false;
			list_yellow[id - 1].bar2 = false;
			list_yellow[id - 1].bar3 = true;
			return;
		}
	}
	
	//zone 1, bar 3
	if(list_yellow[id - 1].bar1 == false && list_yellow[id - 1].bar2 == false && list_yellow[id - 1].bar3 ==true && list_yellow[id - 1].position <= 6 && list_yellow[id - 1].zone == 1 && list_yellow[id - 1].initial == false){
		yToMove = yToMove+box;
		if(id == 1){
			x1_yellow = xToMove;
			y1_yellow = yToMove;
		}
		else if(id == 2){
			x2_yellow = xToMove;
			y2_yellow = yToMove;
		}
		else if(id == 3){
			x3_yellow = xToMove;
			y3_yellow = yToMove;
		}
		else if(id == 4){
			x4_yellow = xToMove;
			y4_yellow = yToMove;
		}
		if(list_yellow[id - 1].position == 6){
			list_yellow[id - 1].lastMove = true;
			list_yellow[id - 1].zone++;
			return;
		}
		
	}
	if(list_yellow[id - 1].lastMove == true){
		yToMove = yToMove+box;
		if(id == 1){
			x1_yellow = xToMove;
			y1_yellow = yToMove;
		}
		else if(id == 2){
			x2_yellow = xToMove;
			y2_yellow = yToMove;
		}
		else if(id == 3){
			x3_yellow = xToMove;
			y3_yellow = yToMove;
		}
		else if(id == 4){
			x4_yellow = xToMove;
			y4_yellow = yToMove;
		}
		list_yellow[id - 1].lastMove = false;
	}

}

//##############################################################################################################################################

function moveCone(id){
	list[id - 1].position++;
	
	if(list[id - 1].zone == 1 && list[id - 1].position<5 && list[id - 1].bar3 == true && list[id - 1].initial == true){//user home, bar 3
		yToMove = yToMove-box;
		if(id == 1){
			x1_red = xToMove;
			y1_red = yToMove;
		}
		else if(id == 2){
			x2_red = xToMove;
			y2_red = yToMove;
		}
		else if(id == 3){
			x3_red = xToMove;
			y3_red = yToMove;
		}
		else if(id == 4){
			x4_red = xToMove;
			y4_red = yToMove;
		}

	}
	
	else if(list[id - 1].zone == 1 && list[id - 1].position==5&& list[id - 1].initial == true){
		yToMove = yToMove-box;
		xToMove = xToMove-box;
		if(id == 1){
			x1_red = xToMove;
			y1_red = yToMove;
		}
		else if(id == 2){
			x2_red = xToMove;
			y2_red = yToMove;
		}
		else if(id == 3){
			x3_red = xToMove;
			y3_red = yToMove;
		}
		else if(id == 4){
			x4_red = xToMove;
			y4_red = yToMove;
		}
		list[id - 1].zone++;
		list[id - 1].position = 0;
		list[id - 1].bar1 = true;
		list[id - 1].initial = false;
	}
	
	//zone 2, bar 1
	else if(list[id - 1].bar1 == true && list[id - 1].zone == 2 && list[id - 1].position <= 5){
		xToMove = xToMove-box;
		if(id == 1){
			x1_red = xToMove;
			y1_red = yToMove;
		}
		else if(id == 2){
			x2_red = xToMove;
			y2_red = yToMove;
		}
		else if(id == 3){
			x3_red = xToMove;
			y3_red = yToMove;
		}
		else if(id == 4){
			x4_red = xToMove;
			y4_red = yToMove;
		}
		if(list[id - 1].position == 5){
			list[id - 1].position = 1;
			list[id - 1].bar1 = false;
			list[id - 1].bar2 = true;
			return;
		}
	}
	
	//zone 2, bar 2
	if(list[id - 1].bar1 == false && list[id - 1].bar2 == true && list[id - 1].position <= 3 && list[id - 1].zone == 2){
		yToMove = yToMove-box;
		if(id == 1){
			x1_red = xToMove;
			y1_red = yToMove;
		}
		else if(id == 2){
			x2_red = xToMove;
			y2_red = yToMove;
		}
		else if(id == 3){
			x3_red = xToMove;
			y3_red = yToMove;
		}
		else if(id == 4){
			x4_red = xToMove;
			y4_red = yToMove;
		}
		if(list[id - 1].position == 3){
			list[id - 1].position = 1;
			list[id - 1].bar1 = false;
			list[id - 1].bar2 = false;
			list[id - 1].bar3 = true;
			return;
		}
	}
	
	//zone 2, bar 3
	if(list[id - 1].bar1 == false && list[id - 1].bar2 == false && list[id - 1].bar3 ==true && list[id - 1].position <= 6 && list[id - 1].zone == 2){
		xToMove = xToMove+box;
		if(id == 1){
			x1_red = xToMove;
			y1_red = yToMove;
		}
		else if(id == 2){
			x2_red = xToMove;
			y2_red = yToMove;
		}
		else if(id == 3){
			x3_red = xToMove;
			y3_red = yToMove;
		}
		else if(id == 4){
			x4_red = xToMove;
			y4_red = yToMove;
		}
		if(list[id - 1].position == 6){
			list[id - 1].zone++;
			return;
		}
	}
	
	//zone 3, special case
	else if(list[id - 1].zone == 3 && list[id - 1].bar3 == true && list[id - 1].position == 7){
		list[id - 1].bar3 = false;
			yToMove = yToMove-box;
			xToMove = xToMove+box;
			if(id == 1){
				x1_red = xToMove;
				y1_red = yToMove;
			}
			else if(id == 2){
				x2_red = xToMove;
				y2_red = yToMove;
			}
			else if(id == 3){
				x3_red = xToMove;
				y3_red = yToMove;
			}
			else if(id == 4){
				x4_red = xToMove;
				y4_red = yToMove;
			}
			list[id - 1].position = 0;
			list[id - 1].bar1 = true;
			return;
		
	}
		
	///CODE FOR ZONE 3,bar 1
	if(list[id - 1].bar1 == true && list[id - 1].zone == 3 && list[id - 1].position <= 5){
		yToMove = yToMove-box;
		if(id == 1){
			x1_red = xToMove;
			y1_red = yToMove;
		}
		else if(id == 2){
			x2_red = xToMove;
			y2_red = yToMove;
		}
		else if(id == 3){
			x3_red = xToMove;
			y3_red = yToMove;
		}
		else if(id == 4){
			x4_red = xToMove;
			y4_red = yToMove;
		}
		if(list[id - 1].position == 5){
			list[id - 1].position = 1;
			list[id - 1].bar1 = false;
			list[id - 1].bar2 = true;
			return;
		}
	}
	//zone 3, bar 2
	if(list[id - 1].bar1 == false && list[id - 1].bar2 == true && list[id - 1].position <= 3 && list[id - 1].zone == 3){
		xToMove = xToMove+box;
		if(id == 1){
			x1_red = xToMove;
			y1_red = yToMove;
		}
		else if(id == 2){
			x2_red = xToMove;
			y2_red = yToMove;
		}
		else if(id == 3){
			x3_red = xToMove;
			y3_red = yToMove;
		}
		else if(id == 4){
			x4_red = xToMove;
			y4_red = yToMove;
		}
		if(list[id - 1].position == 3){
			list[id - 1].position = 1;
			list[id - 1].bar1 = false;
			list[id - 1].bar2 = false;
			list[id - 1].bar3 = true;
			return;
		}
	}
	
	//zone 3, bar 3
	if(list[id - 1].bar1 == false && list[id - 1].bar2 == false && list[id - 1].bar3 ==true && list[id - 1].position <= 6 && list[id - 1].zone == 3){
		yToMove = yToMove+box;
		if(id == 1){
			x1_red = xToMove;
			y1_red = yToMove;
		}
		else if(id == 2){
			x2_red = xToMove;
			y2_red = yToMove;
		}
		else if(id == 3){
			x3_red = xToMove;
			y3_red = yToMove;
		}
		else if(id == 4){
			x4_red = xToMove;
			y4_red = yToMove;
		}
		if(list[id - 1].position == 6){
			list[id - 1].zone++;
			return;
		}
	}
	//zone 4, special case
	else if(list[id - 1].zone == 4 && list[id - 1].bar3 == true && list[id - 1].position == 7){
		list[id - 1].bar3 = false;
			yToMove = yToMove+box;
			xToMove = xToMove+box;
			if(id == 1){
				x1_red = xToMove;
				y1_red = yToMove;
			}
			else if(id == 2){
				x2_red = xToMove;
				y2_red = yToMove;
			}
			else if(id == 3){
				x3_red = xToMove;
				y3_red = yToMove;
			}
			else if(id == 4){
				x4_red = xToMove;
				y4_red = yToMove;
			}
			list[id - 1].position = 0;
			list[id - 1].bar1 = true;
			return;
		
	}
		
	///CODE FOR ZONE 4,bar 1
	if(list[id - 1].bar1 == true && list[id - 1].zone == 4 && list[id - 1].position <= 5){
		xToMove = xToMove+box;
		if(id == 1){
			x1_red = xToMove;
			y1_red = yToMove;
		}
		else if(id == 2){
			x2_red = xToMove;
			y2_red = yToMove;
		}
		else if(id == 3){
			x3_red = xToMove;
			y3_red = yToMove;
		}
		else if(id == 4){
			x4_red = xToMove;
			y4_red = yToMove;
		}
		if(list[id - 1].position == 5){
			list[id - 1].position = 1;
			list[id - 1].bar1 = false;
			list[id - 1].bar2 = true;
			return;
		}
	}
	//zone 4, bar 2
	if(list[id - 1].bar1 == false && list[id - 1].bar2 == true && list[id - 1].position <= 3 && list[id - 1].zone == 4){
		yToMove = yToMove+box;
		if(id == 1){
			x1_red = xToMove;
			y1_red = yToMove;
		}
		else if(id == 2){
			x2_red = xToMove;
			y2_red = yToMove;
		}
		else if(id == 3){
			x3_red = xToMove;
			y3_red = yToMove;
		}
		else if(id == 4){
			x4_red = xToMove;
			y4_red = yToMove;
		}
		if(list[id - 1].position == 3){
			list[id - 1].position = 1;
			list[id - 1].bar1 = false;
			list[id - 1].bar2 = false;
			list[id - 1].bar3 = true;
			return;
		}
	}
	//zone 4, bar 3
	if(list[id - 1].bar1 == false && list[id - 1].bar2 == false && list[id - 1].bar3 ==true && list[id - 1].position <= 6 && list[id - 1].zone == 4){
		xToMove = xToMove-box;
		if(id == 1){
			x1_red = xToMove;
			y1_red = yToMove;
		}
		else if(id == 2){
			x2_red = xToMove;
			y2_red = yToMove;
		}
		else if(id == 3){
			x3_red = xToMove;
			y3_red = yToMove;
		}
		else if(id == 4){
			x4_red = xToMove;
			y4_red = yToMove;
		}
		if(list[id - 1].position == 6){
			list[id - 1].zone = 1;
			return;
		}
	}
	
	//zone 1, special case
	else if(list[id - 1].zone == 1 && list[id - 1].bar3 == true && list[id - 1].position == 7){
			yToMove = yToMove+box;
			xToMove = xToMove-box;
			if(id == 1){
				x1_red = xToMove;
				y1_red = yToMove;
			}
			else if(id == 2){
				x2_red = xToMove;
				y2_red = yToMove;
			}
			else if(id == 3){
				x3_red = xToMove;
				y3_red = yToMove;
			}
			else if(id == 4){
				x4_red = xToMove;
				y4_red = yToMove;
			}
			list[id - 1].zone = 1;
			list[id - 1].position = 0;
			list[id - 1].bar1 = true;
			list[id - 1].bar3 = false;
			return;
		
	}
	///CODE FOR ZONE 1,bar 1
	if(list[id - 1].bar1 == true && list[id - 1].zone == 1 && list[id - 1].position <= 5){
		yToMove = yToMove+box;
		if(id == 1){
			x1_red = xToMove;
			y1_red = yToMove;
		}
		else if(id == 2){
			x2_red = xToMove;
			y2_red = yToMove;
		}
		else if(id == 3){
			x3_red = xToMove;
			y3_red = yToMove;
		}
		else if(id == 4){
			x4_red = xToMove;
			y4_red = yToMove;
		}
		if(list[id - 1].position == 5){
			list[id - 1].position = 1;
			list[id - 1].bar1 = false;
			list[id - 1].bar2 = true;
			return;
		}
	}
	//zone 1, bar 2
	if(list[id - 1].bar1 == false && list[id - 1].bar2 == true && list[id - 1].position <= 2 && list[id - 1].zone == 1){
		xToMove = xToMove-box;
		if(id == 1){
			x1_red = xToMove;
			y1_red = yToMove;
		}
		else if(id == 2){
			x2_red = xToMove;
			y2_red = yToMove;
		}
		else if(id == 3){
			x3_red = xToMove;
			y3_red = yToMove;
		}
		else if(id == 4){
			x4_red = xToMove;
			y4_red = yToMove;
		}
		if(list[id - 1].position == 2){
			list[id - 1].position = 1;
			list[id - 1].bar1 = false;
			list[id - 1].bar2 = false;
			list[id - 1].bar3 = true;
			return;
		}
	}
	
	//zone 1, bar 3
	if(list[id - 1].bar1 == false && list[id - 1].bar2 == false && list[id - 1].bar3 ==true && list[id - 1].position <= 6 && list[id - 1].zone == 1 && list[id - 1].initial == false){
		yToMove = yToMove-box;
		if(id == 1){
			x1_red = xToMove;
			y1_red = yToMove;
		}
		else if(id == 2){
			x2_red = xToMove;
			y2_red = yToMove;
		}
		else if(id == 3){
			x3_red = xToMove;
			y3_red = yToMove;
		}
		else if(id == 4){
			x4_red = xToMove;
			y4_red = yToMove;
		}
		if(list[id - 1].position == 6){
			list[id - 1].lastMove = true;
			list[id - 1].zone++;
			return;
		}
		
	}
	if(list[id - 1].lastMove == true){
		yToMove = yToMove-box;
		if(id == 1){
			x1_red = xToMove;
			y1_red = yToMove;
		}
		else if(id == 2){
			x2_red = xToMove;
			y2_red = yToMove;
		}
		else if(id == 3){
			x3_red = xToMove;
			y3_red = yToMove;
		}
		else if(id == 4){
			x4_red = xToMove;
			y4_red = yToMove;
		}
		list[id - 1].lastMove = false;
	}

}
function cl(){
	test.clear();
	}


