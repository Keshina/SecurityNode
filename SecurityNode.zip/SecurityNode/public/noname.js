/**
 * http://usejsdoc.org/
 */
var posArrX = new Array();
var posArrY = new Array();
var random = 0;
function checkCollision(){
	document.getElementById("collisionMsg").innerHTML = "";
	posArrX[0] = new Array(x1_red,x2_red,x3_red,x4_red);
	posArrX[1] = new Array(x1_yellow,x2_yellow,x3_yellow,x4_yellow);
	posArrY[0] = new Array(y1_red,y2_red,y3_red,y4_red);
	posArrY[1] = new Array(y1_yellow,y2_yellow,y3_yellow,y4_yellow);
	for (var i=0; i < posArrX.length; i++) {
		for (var j=0; j < posArrX[i].length; j++) {
			var checkFlagX = posArrX[0][i] - posArrX[1][j];
			var checkFlagY = posArrY[0][i] - posArrY[1][j];
			if(checkFlagX < 10 && checkFlagY < 10 && checkFlagX >=-10 && checkFlagY >=-10){
				if(playerTurn == 0){
					
					if(posArrX[1][j] == x1_yellow && posArrY[1][j] == y1_yellow){
						document.getElementById("collisionMsg").innerHTML = "Player 1 killed Player 2's cone 1!";
						x1_yellow = 382;
						y1_yellow = 67;
						list_yellow[0]= { position: 0, zone: 0, bar1: false, bar2: false, bar3: false, initial: true, firstMove: true, lastMove: false, reachedHome: false};
						haveAMove_y = false;
						return true;
					}
					if(posArrX[1][j] == x2_yellow && posArrY[1][j] == y2_yellow){
						document.getElementById("collisionMsg").innerHTML = "Player 1 killed Player 2's cone 2!";
						x1_yellow = 382+box;
						y1_yellow = 67+box;
						list_yellow[1]= { position: 0, zone: 0, bar1: false, bar2: false, bar3: false, initial: true, firstMove: true, lastMove: false, reachedHome: false};
						haveAMove_y = false;
						return true;
					}
					if(posArrX[1][j] == x3_yellow && posArrY[1][j] == y3_yellow){
						document.getElementById("collisionMsg").innerHTML = "Player 1 killed Player 2's cone 3!";
						x1_yellow = 382-box;
						y1_yellow = 67+box;
						list_yellow[2]= { position: 0, zone: 0, bar1: false, bar2: false, bar3: false, initial: true, firstMove: true, lastMove: false, reachedHome: false};
						haveAMove_y = false;
						return true;
					}
					if(posArrX[1][j] == x4_yellow && posArrY[1][j] == y4_yellow){
						document.getElementById("collisionMsg").innerHTML = "Player 1 killed Player 2's cone 4!";
						x1_yellow = 382;
						y1_yellow = 67+box+box;
						list_yellow[3]= { position: 0, zone: 0, bar1: false, bar2: false, bar3: false, initial: true, firstMove: true, lastMove: false, reachedHome: false};
						haveAMove_y = false;
						return true;
					}
					
				}
				if(playerTurn == 1){
					
					if(posArrX[0][i] == x1_red && posArrY[0][i] == y1_red){
						x1_red = 100;
						y1_red = 350;
						list[0] = { position: 0, zone: 0, bar1: false, bar2: false, bar3: false, initial: true, firstMove: true, lastMove: false, reachedHome: false};
						document.getElementById("collisionMsg").innerHTML = "Player 2 killed Player 1's cone 1!";
						haveAMove = false;
						return true;
					}
					if(posArrX[0][i] == x2_red && posArrY[0][i] == y2_red){
						x2_red = 100+box;
						y2_red = 382;
						list[1] = { position: 0, zone: 0, bar1: false, bar2: false, bar3: false, initial: true, firstMove: true, lastMove: false, reachedHome: false};
						document.getElementById("collisionMsg").innerHTML = "Player 2 killed Player 1's cone 2!";
						haveAMove = false;
						return true;
					}
					if(posArrX[1][j] == x3_red && posArrY[1][j] == y3_red){
						x3_red = 100-box;
						y3_red = 382;
						list[2] = { position: 0, zone: 0, bar1: false, bar2: false, bar3: false, initial: true, firstMove: true, lastMove: false, reachedHome: false};
						document.getElementById("collisionMsg").innerHTML = "Player 2 killed Player 1's cone 3!";
						haveAMove = false;
						return true;
					}
					if(posArrX[1][j] == x4_red && posArrY[1][j] == y4_red){
						x4_red = 100;
						y4_red = 350+box+box;
						list[3] = { position: 0, zone: 0, bar1: false, bar2: false, bar3: false, initial: true, firstMove: true, lastMove: false, reachedHome: false};
						document.getElementById("collisionMsg").innerHTML = "Player 2 killed Player 1's cone 4!";
						haveAMove = false;
						return true;
					}
				}
				
			}
			else{
			}
		}
	}
	
}



function disableRed(){
	document.getElementById("oneRone").disabled = true;
	document.getElementById("oneRtwo").disabled = true;
	document.getElementById("oneRthree").disabled = true;
	document.getElementById("oneRfour").disabled = true;
	document.getElementById("oneRfive").disabled = true;
	document.getElementById("oneRsix").disabled = true;
	
	document.getElementById("twoRone").disabled = true;
	document.getElementById("twoRtwo").disabled = true;
	document.getElementById("twoRthree").disabled = true;
	document.getElementById("twoRfour").disabled = true;
	document.getElementById("twoRfive").disabled = true;
	document.getElementById("twoRsix").disabled = true;
	
	document.getElementById("threeRone").disabled = true;
	document.getElementById("threeRtwo").disabled = true;
	document.getElementById("threeRthree").disabled = true;
	document.getElementById("threeRfour").disabled = true;
	document.getElementById("threeRfive").disabled = true;
	document.getElementById("threeRsix").disabled = true;
	
	document.getElementById("fourRone").disabled = true;
	document.getElementById("fourRtwo").disabled = true;
	document.getElementById("fourRthree").disabled = true;
	document.getElementById("fourRfour").disabled = true;
	document.getElementById("fourRfive").disabled = true;
	document.getElementById("fourRsix").disabled = true;
	
}
function disableYellow(){
	document.getElementById("oneYone").disabled = true;
	document.getElementById("oneYtwo").disabled = true;
	document.getElementById("oneYthree").disabled = true;
	document.getElementById("oneYfour").disabled = true;
	document.getElementById("oneYfive").disabled = true;
	document.getElementById("oneYsix").disabled = true;
	
	document.getElementById("twoYone").disabled = true;
	document.getElementById("twoYtwo").disabled = true;
	document.getElementById("twoYthree").disabled = true;
	document.getElementById("twoYfour").disabled = true;
	document.getElementById("twoYfive").disabled = true;
	document.getElementById("twoYsix").disabled = true;
	
	document.getElementById("threeYone").disabled = true;
	document.getElementById("threeYtwo").disabled = true;
	document.getElementById("threeYthree").disabled = true;
	document.getElementById("threeYfour").disabled = true;
	document.getElementById("threeYfive").disabled = true;
	document.getElementById("threeYsix").disabled = true;
	
	document.getElementById("fourYone").disabled = true;
	document.getElementById("fourYtwo").disabled = true;
	document.getElementById("fourYthree").disabled = true;
	document.getElementById("fourYfour").disabled = true;
	document.getElementById("fourYfive").disabled = true;
	document.getElementById("fourYsix").disabled = true;
	
}
var randArr = new Array();
randArr[0] = 1;
//randArr[1] = 1;
for(var i =1; i < 50; i++){
	randArr[i] = Math.floor(Math.random()*6)+1;
}
/*
randArr
randArr[2] = 6;
randArr[3] = 1;
randArr[4] = 6;
randArr[5] = 1;
randArr[6] = 6;
randArr[7] = 1;
randArr[8] = 6;
randArr[9] = 1;
randArr[10] = 6;
randArr[11] = 1;
randArr[12] = 6;
randArr[13] = 1;
randArr[14] = 6;
randArr[15] = 1;
randArr[16] = 6;
randArr[17] = 1;
randArr[18] = 6;
randArr[19] = 1;
randArr[20] = 6;
randArr[21] = 1;
randArr[22] = 6;
randArr[23] = 1;
randArr[24] = 6;
randArr[25] = 1;*/
var count = -1;
function rollDice(){
	count++;
	//random = Math.floor(Math.random()*6)+1;
	random = randArr[count];
	
	document.getElementById("status").innerHTML = "You rolled "+ random +"!";
	buttonSetup();
}
var haveAMove = false;
var haveAMove_y = false;
function buttonSetup(){
	if(playerTurn == 0){
		
		if(random == 1){
			if(list[0].reachedHome == false){
				document.getElementById("oneRone").disabled = false;
				haveAMove = true;
			}
			if(list[1].reachedHome == false){
				document.getElementById("twoRone").disabled = false;
				haveAMove = true;
			}
			if(list[2].reachedHome == false){
				document.getElementById("threeRone").disabled = false;
				haveAMove = true;
			}
			if(list[3].reachedHome == false){
				document.getElementById("fourRone").disabled = false;
				haveAMove = true;
			}
			
		}
		else if(random == 2 && list[0].reachedHome == false){
			if(list[0].firstMove == false){
				document.getElementById("oneRtwo").disabled = false;
				document.getElementById("oneRone").disabled = false;
				haveAMove = true;
				
			}
			if(list[1].firstMove == false && list[1].reachedHome == false){
				document.getElementById("twoRtwo").disabled = false;
				document.getElementById("twoRone").disabled = false;
				haveAMove = true;
				
			}
			if(list[2].firstMove == false && list[2].reachedHome == false){
				document.getElementById("threeRtwo").disabled = false;
				document.getElementById("threeRone").disabled = false;
				haveAMove = true;
				
			}
			if(list[3].firstMove == false && list[3].reachedHome == false){
				document.getElementById("fourRtwo").disabled = false;
				document.getElementById("fourRone").disabled = false;
				haveAMove = true;
				
			}
			
		}
		else if(random == 3){
			if(list[0].firstMove == false && list[0].reachedHome == false){
				document.getElementById("oneRthree").disabled = false;
				haveAMove = true;
				
			}
			if(list[1].firstMove == false && list[1].reachedHome == false){
				document.getElementById("twoRthree").disabled = false;
				haveAMove = true;
				
			}
			if(list[2].firstMove == false && list[2].reachedHome == false){
				document.getElementById("threeRthree").disabled = false;
				haveAMove = true;
				
			}
			if(list[3].firstMove == false && list[3].reachedHome == false){
				document.getElementById("fourRthree").disabled = false;
				haveAMove = true;
				
			}
			
		}
		else if(random == 4){
			if(list[0].firstMove == false && list[0].reachedHome == false){
				document.getElementById("oneRfour").disabled = false;
				document.getElementById("oneRtwo").disabled = false;
				haveAMove = true;
				
			}
			if(list[1].firstMove == false && list[1].reachedHome == false){
				document.getElementById("twoRfour").disabled = false;
				document.getElementById("twoRtwo").disabled = false;
				haveAMove = true;
				
			}
			if(list[2].firstMove == false && list[2].reachedHome == false){
				document.getElementById("threeRfour").disabled = false;
				document.getElementById("threeRtwo").disabled = false;
				haveAMove = true;
				
			}
			if(list[3].firstMove == false && list[3].reachedHome == false){
				document.getElementById("fourRfour").disabled = false;
				document.getElementById("fourRtwo").disabled = false;
				haveAMove = true;
				
			}
			
		}
		else if(random == 5){
			if(list[0].firstMove == false && list[0].reachedHome == false){
				document.getElementById("oneRfive").disabled = false;
				haveAMove = true;
				
			}
			if(list[1].firstMove == false && list[1].reachedHome == false){
				document.getElementById("twoRfive").disabled = false;
				haveAMove = true;
				
			}
			if(list[2].firstMove == false && list[2].reachedHome == false){
				document.getElementById("threeRfive").disabled = false;
				haveAMove = true;
				
			}
			if(list[3].firstMove == false && list[3].reachedHome == false){
				document.getElementById("fourRfive").disabled = false;
				haveAMove = true;
				
			}
			
		}
		else if(random == 6){
			if(list[0].reachedHome == false){
				document.getElementById("oneRsix").disabled = false;
				haveAMove = true;
			}
			if(list[1].reachedHome == false){
				document.getElementById("twoRsix").disabled = false;
				haveAMove = true;
			}
			if(list[2].reachedHome == false){
				document.getElementById("threeRsix").disabled = false;
				haveAMove = true;
			}
			if(list[3].reachedHome == false){
				document.getElementById("fourRsix").disabled = false;
				haveAMove = true;
			}
			
			if(list[0].firstMove == false && list[0].reachedHome == false){
				document.getElementById("oneRthree").disabled = false;
				haveAMove = true;
			}
			if(list[1].firstMove == false && list[1].reachedHome == false){
				document.getElementById("twoRthree").disabled = false;
				haveAMove = true;
				
			}
			if(list[2].firstMove == false && list[2].reachedHome == false){
				document.getElementById("threeRthree").disabled = false;
				haveAMove = true;
				
			}
			if(list[3].firstMove == false && list[3].reachedHome == false){
				document.getElementById("fourRthree").disabled = false;
				haveAMove = true;
				
			}
			
				
		}
		if(haveAMove == false && random!=0){
			document.getElementById("diceTurn").innerHTML = "Player 2 - roll the dice:";
			document.getElementById("status").innerHTML = "oh, oh player 1 can't make a move, you got a " +random +"!";
			playerTurn = 1;
			drawCones();
			drawConesYellow();
			disableRed();
			disableYellow();
		}
	}
	else if(playerTurn == 1){
		
		if(random == 1){
			if(list_yellow[0].reachedHome == false){
				document.getElementById("oneYone").disabled = false;
				haveAMove_y = true;
			}
			if(list_yellow[1].reachedHome == false){
				document.getElementById("twoYone").disabled = false;
				haveAMove_y = true;
			}
			if(list_yellow[2].reachedHome == false){
				document.getElementById("threeYone").disabled = false;
				haveAMove_y = true;
			}
			if(list_yellow[3].reachedHome == false){
				document.getElementById("fourYone").disabled = false;
				haveAMove_y = true;
			}
		}
		else if(random == 2){
			if(list_yellow[0].firstMove == false && list_yellow[0].reachedHome == false){
				document.getElementById("oneYtwo").disabled = false;
				document.getElementById("oneYone").disabled = false;
				haveAMove_y = true;
				
			}
			if(list_yellow[1].firstMove == false && list_yellow[1].reachedHome == false){
				document.getElementById("twoYtwo").disabled = false;
				document.getElementById("twoYone").disabled = false;
				haveAMove_y = true;
				
			}
			if(list_yellow[2].firstMove == false && list_yellow[2].reachedHome == false){
				document.getElementById("threeYtwo").disabled = false;
				document.getElementById("threeYone").disabled = false;
				haveAMove_y = true;
				
			}
			if(list_yellow[3].firstMove == false && list_yellow[3].reachedHome == false){
				document.getElementById("fourYtwo").disabled = false;
				document.getElementById("fourYone").disabled = false;
				haveAMove_y = true;
				
			}
			
		}
		else if(random == 3){
			if(list_yellow[0].firstMove == false && list_yellow[0].reachedHome == false){
				document.getElementById("oneYthree").disabled = false;
				haveAMove_y = true;
				
			}
			if(list_yellow[1].firstMove == false && list_yellow[1].reachedHome == false){
				document.getElementById("twoYthree").disabled = false;
				haveAMove_y = true;
			}
			if(list_yellow[2].firstMove == false && list_yellow[2].reachedHome == false){
				document.getElementById("threeYthree").disabled = false;
				haveAMove_y = true;
				
			}
			if(list_yellow[3].firstMove == false && list_yellow[3].reachedHome == false){
				document.getElementById("fourYthree").disabled = false;
				haveAMove_y = true;
				
			}
			
		}
		else if(random == 4){
			if(list_yellow[0].firstMove == false && list_yellow[0].reachedHome == false){
				document.getElementById("oneYfour").disabled = false;
				document.getElementById("oneYtwo").disabled = false;
				haveAMove_y = true;
				
			}
			if(list_yellow[1].firstMove == false && list_yellow[1].reachedHome == false){
				document.getElementById("twoYfour").disabled = false;
				document.getElementById("twoYtwo").disabled = false;
				haveAMove_y = true;
				
			}
			if(list_yellow[2].firstMove == false && list_yellow[2].reachedHome == false){
				document.getElementById("threeYfour").disabled = false;
				document.getElementById("threeYtwo").disabled = false;
				haveAMove_y = true;
				
			}
			if(list_yellow[3].firstMove == false && list_yellow[3].reachedHome == false){
				document.getElementById("fourYfour").disabled = false;
				document.getElementById("fourYtwo").disabled = false;
				haveAMove_y = true;
			}
			
		}
		else if(random == 5){
			if(list_yellow[0].firstMove == false && list_yellow[0].reachedHome == false){
				document.getElementById("oneYfive").disabled = false;
				haveAMove_y = true;
				
			}
			if(list_yellow[1].firstMove == false && list_yellow[1].reachedHome == false){
				document.getElementById("twoYfive").disabled = false;
				haveAMove_y = true;
				
			}
			if(list_yellow[2].firstMove == false && list_yellow[2].reachedHome == false){
				document.getElementById("threeYfive").disabled = false;
				haveAMove_y = true;
				
			}
			if(list_yellow[3].firstMove == false && list_yellow[3].reachedHome == false){
				document.getElementById("fourYfive").disabled = false;
				haveAMove_y = true;
				
			}
			
		}
		else if(random == 6){
			if(list_yellow[0].reachedHome == false){
				document.getElementById("oneYsix").disabled = false;
				haveAMove_y = true;
			}
			if(list_yellow[1].reachedHome == false){
				document.getElementById("twoYsix").disabled = false;
				haveAMove_y = true;
			}
			if(list_yellow[2].reachedHome == false){
				document.getElementById("threeYsix").disabled = false;
				haveAMove_y = true;
			}
			if(list_yellow[3].reachedHome == false){
				document.getElementById("fourYsix").disabled = false;
				haveAMove_y = true;
			}
			
			if(list_yellow[0].firstMove == false  && list_yellow[0].reachedHome == false){
				document.getElementById("oneYthree").disabled = false;
			}
			if(list_yellow[1].firstMove == false && list_yellow[1].reachedHome == false){
				document.getElementById("twoYthree").disabled = false;
				
			}
			if(list_yellow[2].firstMove == false && list_yellow[2].reachedHome == false){
				document.getElementById("threeYthree").disabled = false;
				
			}
			if(list_yellow[3].firstMove == false && list_yellow[3].reachedHome == false){
				document.getElementById("fourYthree").disabled = false;
				
			}
			haveAMove_y = true;
				
		}
		if(haveAMove_y == false && random!=0){
			document.getElementById("diceTurn").innerHTML = "Player 1 - roll the dice:";
			document.getElementById("status").innerHTML = "oh, oh player 2 can't make a move, you got a " +random +"!";
			playerTurn = 0;
		}
		
	}
	
}

