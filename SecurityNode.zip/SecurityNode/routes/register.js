/**
 * register user
 */
var express= require('express');
var expressValidator = require('express-validator');
var bcrypt = require('bcryptjs');
var passport = require('passport');

const saltRound = 10 ;
 
var router = express.Router();
exports.register = function(req, res){
	req.checkBody('username','Username field cannot be empty.').notEmpty();
	req.checkBody('username','Username must be between 5 to 15 characters long').len(5,15);
	req.checkBody('password','Password must be between 8 to 15 characters long').len(8,15);
	req.checkBody('password', 'Password must include one lowercase character, one uppercase character, a number'
			+', and a special character.').matches(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.* )(?=.*[^a-zA-Z0-9]).{8,}$/, "i");
	req.checkBody('repassword','Password must be between 8 to 15 characters long').len(8,15);
	req.checkBody('repassword','Password do not match, please try again').equals(req.body.password);
	var errors = req.validationErrors();
	if(errors){
		//res.render('error',{title:'Ludo Game', errorMsg:'Registration unsuccessful'});				
	res.render('signUp',{title:'Registration unsuccessful',
			errors: errors});
	}
	else{
	var username = req.body.username;
	var password = req.body.password;
	var repassword = req.body.repassword;
	const db = require('../databaseConnector.js');
	bcrypt.hash(password, saltRound,function(err, hash){
		db.query('INSERT INTO user(username, password) VALUES (?,?)',[username,hash],function(error, results, fields){
			if(error) {
			res.render('signUp',{title:'Registration unsuccessful', errorMsg:'This username is already in use.'});
			
			}
			else{
				db.query('SELECT LAST_INSERT_ID() as user_id', function(error, results, fields){
					if(error) 
						{
						res.render('error',{title:'Ludo Game', errorMsg:'Error creating user'});				

						}
					
					var userId= results[0];
					console.log(userId);
					req.login(userId, function(err){
						res.redirect('/dashboard'); //if user logs in, redirecting here
					});
					//res.render('dashboard', { title: 'Registration successful ' });

				});
			}
		});
	});
	
	}
  
  
};

passport.serializeUser(function(userId, done) {
	  done(null, userId);
	});

passport.deserializeUser(function(userId, done) {
	    done(null, userId);
	});



exports.createAccount = function(req,res){
	res.render('signUp', { title: 'Registration' });

};
function authenticationMiddleware () {  
	return (req, res, next) => {
		console.log("req.session.passport.user"+ JSON.stringify(req.session.passport));

	    if (req.isAuthenticated()) {return next();}
	    res.redirect('/');
	};
}

/*var express = require('express');
var router = express.Router();
router.post('/register',function(req,res,next){
	res.render('register',{title:'Registration DONE!!'});
});*/