
/*
 * GET users listing.
 */
const db = require('../databaseConnector.js'); 

exports.join = function(req, res){
 // res.send("respond with a resource");
	//console.log("req id"+req.body.);
	
	console.log("JOINING GAME!!!!!!!!!"+req);
	//if(req){
		if(req.body.button){
			db.query('SELECT * FROM gameState WHERE gameId=?',req.body.button,function(error, results, fields){
				if(error) {
				res.render('error',{title:'Error', errorMsg:'Problem joining the game. Try again later!'});
				
				}
				else{
					var gameStateInfo=results;
					console.log(gameStateInfo);
					if(req.body.player2)
						{
						db.query('UPDATE game SET playerNeeded=?,player2=?, player2Color=? WHERE id=?',["0",req.body.player2,"yellow",req.body.button],function(error, results, fields){
							if(error)
							{
								res.render('error',{title:'Error', errorMsg:'Problem joining the game. Try again later!'});
								
								}
							else{
								res.render('newGame', { title: 'Lugo Game ', gameData:gameStateInfo,color:"yellow"});
										

							}
							});
						}
					else{
						if(req.body.myGame){
							res.render('newGame', { title: 'Lugo Game ', gameData:gameStateInfo,color:"red"});

						}
						else{
							res.render('newGame', { title: 'Lugo Game ', gameData:gameStateInfo,color:"yellow"});
						}

					}
					
					


				}
					
				
					});
		}
		if(req.body.showLog){
			db.query('SELECT logMoves from gameState where gameId=?',[req.body.showLog],function(error, results, field){
				if(error){
					res.render('error',{title:'Ludo Game', errorMsg:'Error Showing log'});				
				}
				else{
					console.log(results[0].logMoves);
					var gamelog ;//= new Array () ;
					var i=0;
					gamelog=results[0].logMoves;
					console.log(gamelog);
					res.render('log',{title:'Ludo Game', gamelog: gamelog});
				}
			});
		}
	//}
//	else
		

	

};

exports.handle = function(req, res){
	res.render('dashboard',{title:'Ludo game', errorMsg:'Problem joining the game. Try again later!'});

}