/**
 * http://usejsdoc.org/
 */
var express= require('express');
var expressValidator = require('express-validator');

var router = express.Router();
exports.signIn = function(req, res){
	
	
	req.checkBody('username','Username field cannot be empty.').notEmpty();
	req.checkBody('password','Password field cannot be empty.').notEmpty();
	
	var errors = req.validationErrors();

	if(errors){
		console.log("Errors:"+ JSON.stringify(errors));
		res.render('index',{title:'Sign in unsuccessful',
			errors: errors});
	}
	else{
		var username = req.body.username;
		var password = req.body.password;
		const db = require('../databaseConnector.js');
		db.query('SELECT password FROM user WHERE username=?',[username],function(error, results, fields){
			console.log(results);
			if(error || results.length<1) {
			res.render('index',{title:'Sign in unsuccessful',errorMsg:'Wrong password or username.'});
			}
			else{
				var hash = results[0].password.toString();
				bcrypt.compare(password,hash,function(err, res){
					if(res === true){
						return done(null, {user_id:results[0].id});
					}
					else{
						return done(null, false);
					}
				});
			}
		})
	}

	
  
  
};