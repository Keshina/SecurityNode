
/*
 * GET home page.
 */
//var session = require('express-session');

var passport = require('passport');
const db = require('../databaseConnector.js'); 



exports.index = function(req, res){
  res.render('index', { title: 'Ludo Game ' });
};

exports.error = function(req, res){
  res.render('error', { title: 'Ludo Game ' });
};
exports.ludoRules = function(req, res){
  res.render('ludoRules', { title: 'Ludo Game ' });
};

exports.dashboard = function(req, res){
	res.render('dashboard', { title: 'Ludo Game'});
};
	
exports.myHistory = function(req, res){
		//console.log(req.user.user_id);
		//console.log(req.isAuthenticated());
			//if(req.user){
	var user = req.user.user_id;
	console.log(user);
	//if(req.user){
		db.query('SELECT game.*,gameState.score_red,gameState.score_yellow,gameState.winner FROM game,gameState where creator=? AND game.id=gameState.gameId',[user],function(error, results){
			if(error) {
				console.log(error);
				res.render('error',{title:'Ludo Game', errorMsg:'Error showing game history'});				
				}
			else{
				var myGameHistory = results;
				db.query('SELECT game.*,gameState.score_red,gameState.score_yellow,gameState.winner FROM game,gameState where player2=? AND game.playerNeeded<>"1" AND game.id=gameState.gameId',[user],function(error, results){
				if(error) {
				res.render('error',{title:'Ludo Game', errorMsg:'Error showing game history'});				
				}
			else{
				var involvedGameHistory=results;
				console.log(JSON.stringify(myGameHistory[0])+"GAME HISTIRY")
								console.log(JSON.stringify(involvedGameHistory[0])+"GAME HISTIRY")

				
				if(involvedGameHistory[0].creator){
				res.render('myHistory', { title: 'Ludo Game ',myGameHistory:myGameHistory,involvedGameHistory:involvedGameHistory });
				}else{
					res.render('error',{title:'Ludo Game', errorMsg:'No game history'});				
				
				}
				}});
			}
		});
	//}

		
			
		
			
};
exports.newGame = function(req, res){
	console.log(JSON.stringify(req.user)+"--USER-------");
	//console.log(req.isAuthenticated());
	var user = req.user.user_id//toString().split(":");
	var creatorcolor="red";
	db.query('INSERT INTO game(creator, creatorColor, playerNeeded, gameFinished ) VALUES (?,?,?,?)',[user,creatorcolor,true,false],function(error){
		if(error) {
				//console.log(error);
				res.render('error',{title:'Ludo Game', errorMsg:'Error creating game'});				
				}
		else{
			console.log('IN HERE !!!!!!!');
			db.query('SELECT LAST_INSERT_ID() as gameId', function(error, results){
			if(error) {
					res.render('error',{title:'Ludo Game', errorMsg:'Error creating game'});				
					}
			var gameId= results;
			console.log("gameId"+gameId[0]);
			db.query('INSERT INTO gameState(gameId ) VALUES (?)',[gameId[0].gameId],function(error){
			if(error) {
				res.render('error',{title:'Ludo Game', errorMsg:'Error creating game'});				
				}
	res.render('newGame', { title: 'Ludo Game ', color:'red', gameId:gameId[0]});
			});
	});
		}
			});
			};
			
			
		exports.existingGame = function(req, res){
				//console.log(req.user.user_id);
				//console.log(req.isAuthenticated());
			//if(req.user){
				
				db.query('SELECT game.*, user.username AS creatorName FROM game,user WHERE playerNeeded=? AND game.creator!=? AND user.id=game.creator',[1,req.user.user_id],function(error, results){
					if(error) {
					res.render('error',{title:'Ludo Game', errorMsg:'Error loading game list'});				
					}
					else{
						db.query('SELECT gameState.logMoves FROM gameState WHERE gameId=?',152,function(error, results){
							if(error) {
								res.render('error',{title:'Ludo Game', errorMsg:'Error creating game'});				
							}
						});
						var userId= req.user.user_id
						var games= results;
//						console.log(JSON.stringify(games[0])+"Game available");
					res.render('existingGame', {title:'Ludo Game', gameList: games, color:'yellow',user:userId });


					}
				});
				
		};
		exports.logout = function(req,res){
			req.logout();
			req.session.destroy();
			res.redirect('/');
		};


				
